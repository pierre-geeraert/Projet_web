create procedure nb_like(IN pictures_id_in int)
  BEGIN

SELECT COUNT(*) as nbr_like
FROM appreciate
WHERE picture_id = pictures_id_in;

END;


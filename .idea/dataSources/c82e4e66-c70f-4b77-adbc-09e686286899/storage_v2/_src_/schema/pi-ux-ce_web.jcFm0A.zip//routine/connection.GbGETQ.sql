create procedure connection(IN email_in varchar(200), IN password_in varchar(200))
  BEGIN
    select email, password from users where users.email=email_in and password=password_in limit 1;
END;


create procedure event_past()
  BEGIN
  SELECT event, description,event_id FROM events WHERE DATEDIFF( event_date, NOW() ) < 0;


END;


create procedure add_category(IN category_in varchar(200))
  BEGIN
    INSERT INTO `category`(category)
VALUES
(category_in);
END;


create procedure delete_product(IN product_id_in int)
  BEGIN

DELETE FROM have
WHERE product_id = product_id_in;

DELETE FROM contain
WHERE product_id = product_id_in;

DELETE FROM products
WHERE product_id = product_id_in;

END;


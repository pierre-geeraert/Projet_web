create procedure register(IN name_in     varchar(200), IN surname_in varchar(200), IN email_in varchar(200),
                          IN password_in varchar(200), IN status_in varchar(200))
  BEGIN
    INSERT INTO `users`(name,surname,email,password,status)
VALUES
(name_in,surname_in,email_in,password_in,status_in);
END;


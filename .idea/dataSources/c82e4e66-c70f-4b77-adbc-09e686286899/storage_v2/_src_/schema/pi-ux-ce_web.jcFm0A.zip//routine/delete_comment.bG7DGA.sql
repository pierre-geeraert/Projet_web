create procedure delete_comment(IN comment_id_in varchar(200))
  BEGIN
    delete from `comments` where comment_id=comment_id_in;
END;


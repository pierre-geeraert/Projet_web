create procedure add_picture(IN url_in varchar(200), IN user_id_in int, IN event_id_in varchar(200))
  BEGIN
    INSERT INTO `pictures`(url, user_id,event_id)
VALUES
(url_in,user_id_in,event_id_in);
END;


create procedure suggest(IN event_in varchar(200), IN description_in varchar(200), IN user_id_in varchar(200))
  BEGIN
    INSERT INTO `events`(`event`, description,event_date,validation,user_id)
VALUES
(event_in,description_in,NULL,FALSE,user_id_in);
END;


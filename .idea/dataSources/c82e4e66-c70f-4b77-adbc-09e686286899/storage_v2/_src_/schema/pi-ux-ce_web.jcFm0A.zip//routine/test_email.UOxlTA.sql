create procedure test_email(IN email_in varchar(200))
  BEGIN
    select * from users where email=email_in;
END;


create procedure best_sell(IN event_in varchar(200), IN description_in varchar(200), IN user_id_in varchar(200))
  BEGIN
  select name from products order by number_of_sales desc limit 3;
END;


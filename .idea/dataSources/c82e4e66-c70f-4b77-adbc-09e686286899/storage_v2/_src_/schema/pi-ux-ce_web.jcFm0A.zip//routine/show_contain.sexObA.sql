create procedure show_contain(IN user_id_in int)
  BEGIN



CREATE OR REPLACE VIEW produit_panier
AS
SELECT name, description, price, url, order_id, products.product_id
FROM products
INNER JOIN contain ON products.product_id = contain.product_id;

SELECT name, description, price, url
FROM produit_panier
WHERE order_id = (
        SELECT order_id
        FROM orders
        WHERE user_id = user_id_in	
        ORDER BY order_id DESC
        LIMIT 1    
    );


END;


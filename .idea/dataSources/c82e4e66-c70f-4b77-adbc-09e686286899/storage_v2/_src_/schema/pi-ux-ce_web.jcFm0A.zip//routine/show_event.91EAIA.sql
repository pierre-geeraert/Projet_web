create procedure show_event(IN event_id_in int)
  BEGIN

SELECT `event`,`description`,`event_date`
FROM `events`
WHERE `event_id`= event_id_in;


END;


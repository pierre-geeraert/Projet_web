create procedure vote(IN user_id_in int, IN event_id_in int)
  BEGIN

INSERT INTO vote (user_id, event_id)
VALUES (user_id_in,event_id_in);

END;


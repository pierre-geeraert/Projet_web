create procedure nb_vote(IN event_id_in int)
  BEGIN

SELECT COUNT(*)
FROM vote
WHERE event_id = event_id_in;

END;


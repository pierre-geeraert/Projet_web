create procedure comment(IN comment_in int, IN picture_id_in int, IN user_id_in int)
  BEGIN
    INSERT INTO comments (comments, comment_date, picture_id, user_id)
VALUES (comment_in, NOW(), picture_id_in, user_id_in);

END;


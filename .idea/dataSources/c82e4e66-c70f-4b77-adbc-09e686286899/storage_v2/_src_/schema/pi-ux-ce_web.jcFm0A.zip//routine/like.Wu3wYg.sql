create procedure `like`(IN user_id_in int, IN picture_id_in int)
  BEGIN
    INSERT INTO appreciate(user_id, picture_id)
      VALUES(user_id_in, picture_id_in);

END;


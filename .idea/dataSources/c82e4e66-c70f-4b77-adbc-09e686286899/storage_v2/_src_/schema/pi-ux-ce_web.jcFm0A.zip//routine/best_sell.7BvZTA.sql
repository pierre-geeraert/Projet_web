create procedure best_sell()
  BEGIN
  select name from products order by number_of_sales desc limit 3;
END;


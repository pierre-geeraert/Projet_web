create procedure best_sell()
  BEGIN
  select * from products order by number_of_sales desc limit 3;
END;


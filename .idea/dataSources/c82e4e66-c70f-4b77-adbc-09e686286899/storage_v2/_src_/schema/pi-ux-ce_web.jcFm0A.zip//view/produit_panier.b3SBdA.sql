create view produit_panier as
  select
    `pi-ux-ce_web`.`products`.`name`        AS `name`,
    `pi-ux-ce_web`.`products`.`description` AS `description`,
    `pi-ux-ce_web`.`products`.`price`       AS `price`,
    `pi-ux-ce_web`.`products`.`url`         AS `url`,
    `pi-ux-ce_web`.`contain`.`order_id`     AS `order_id`,
    `pi-ux-ce_web`.`products`.`product_id`  AS `product_id`
  from (`pi-ux-ce_web`.`products`
    join `pi-ux-ce_web`.`contain`
      on ((`pi-ux-ce_web`.`products`.`product_id` = `pi-ux-ce_web`.`contain`.`product_id`)));


create procedure download()
  BEGIN
    select url from pictures;
END;


create procedure add_event(IN event_in   varchar(250), IN descrition_in varchar(250), IN event_date_in date,
                           IN user_id_in int)
  BEGIN

INSERT INTO `events`(`event`, description, event_date, validation, user_id)
VALUES (event_in, descrition_in, event_date_in, TRUE, user_id_in);

END;


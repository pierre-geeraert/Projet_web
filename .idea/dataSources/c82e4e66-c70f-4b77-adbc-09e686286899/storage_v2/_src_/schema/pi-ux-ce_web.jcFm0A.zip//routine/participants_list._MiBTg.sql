create procedure participants_list(IN event_id_in int)
  BEGIN

SELECT users.name, users.surname
FROM users, subscribe
WHERE subscribe.user_id = users.user_id AND event_id = event_id_in;


END;

